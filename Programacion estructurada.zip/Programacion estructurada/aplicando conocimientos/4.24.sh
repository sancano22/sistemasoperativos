#!/bin/bash
# menuBreak.sh Muestra un modo de acabar la iteración de un bucle con break

while true; do
echo " Seleccione su lenguaje de programación favorito:" 
echo "1.  Bash"
echo "2.  Awk"
echo "3.  Java"
echo "4.  C++"
echo

echo -n "Selecciona un menú, o 0 para salir: "
read opcion
echo

case $opcion in
     1)
     	echo "Ha seleccionado el menu de Bash"
     ;;
     2)
     	echo "Ha seleccionado el menu de Awk"
     ;;
     3)
     	echo "Ha seleccionado el menu de Java"
     ;;
     4)
     	echo "Ha seleccionado el menu de C++"
     ;;     
     0)
     echo "OK, Hasta la próxima!"
     break
     ;;
     *)
     echo "Opción incorrecta. Recuerde, valores en el rango [0-4]"
     ;;
esac  
done

