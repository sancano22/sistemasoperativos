#!/bin/bash
# mcdRecursivo.sh Máximo Común Divisor Recursivo

uso()
{
  echo 
  echo "Uso del MCD:"
  echo "`basename $0` primerNumero segundoNumero"
  echo
  exit 1
}

mcd ()
{
  # Se asignan los valores
  m=$1
  n=$2

  # Se verifica que los argumentos sean correctos 
  if [ $n -eq 0 -a $m -eq 0 ]; then
    echo "mcd(0,0) no está definido!"
    exit 1
  elif [ $m -eq 0 ]; then
    return $n
  elif [ $n -eq 0 ]; then
    return $m
  fi

  # Llamada recursiva a la función
  # El primer parámetro es el resto de la operación $n / $m,
  # El segundo parámetro es $m
  # El tercer parámetro es $n
  # Note que $n y $m se invierte continuamente
  mcd $(( $n % $m )) $m
}

######################
# Programa principal #
######################

# Control del número de parámetros
if [ $# -ne 2 ]; then
  uso
fi

# Primera llamada a la función con los argumentos de la línea de comandos 
mcd $1 $2

# Impresión del resultado
MCD=$?
echo "El MCD de $1 y $2 es: $MCD"

