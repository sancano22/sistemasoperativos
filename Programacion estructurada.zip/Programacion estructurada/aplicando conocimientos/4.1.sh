#!/bin/bash
# operar.sh Operaciones matemáticas sobre dos números

echo -n "Deme el primer operando: "
read a
echo -n "Deme el primer operando: "
read b

echo 
echo Operaciones
echo ===========
echo Suma: $a+$b=$(($a+$b))
echo Resta: $a-$b=$(($a-$b))
echo Multiplicación: $a*$b=$(($a*$b))
echo División: $a/$b=$(($a/$b))
