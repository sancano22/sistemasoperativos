#!/bin/bash
#Pide valores numéricos (validados) hasta que se introduzca 0
#Tras esto calcula la suma y media de los valores introducidos

num=0 #número de valores introducidos
suma=0 #suma de los valores introducidos

read -p "Deme un número (0 para salir): " n
until [ $n -eq 0 2> /dev/null ] ; do
	if [ $n -eq $n 2> /dev/null ] ; then #numérico
		suma=`expr $suma + $n`
		num=`expr $num + 1`
	fi
	read -p "Deme un número (0 para salir): " n
done

#Se ha introducido 0 => calcular la suma y media
echo $num valores numéricos introducidos
echo Suma=$suma
#Se evitan divisiones por cero
echo -n Media=
if [ $num -gt 0 ] ; then
	echo "scale=2;$suma/$num" | bc  #con scale=2 se muestran 2 decimales
else
	echo 0.0
fi


	
