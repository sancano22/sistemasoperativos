#!/bin/bash
# symlinks.sh: Guarda los enlaces simbólicos de un directorio en un archivo.

OUTFILE=symlinks.list                         # Fichero de salida

directorio=${1-`pwd`}
# Si no es especifica un directorio se toma,
# el directorio actual.


echo "Enlaces simbólicos del directorio \"$directorio\"" > "$OUTFILE"
echo "---------------------------" >> "$OUTFILE"

for fichero in "$( find $directorio -type l )"    # -type l = enlace simbólico
do
  echo "$fichero"
done | sort >> "$OUTFILE"                     
#           ^^^^^^^^^^^^^                       Redirección al fichero de salida.

