#!/bin/bash
# parimpar.sh  Determina si el valor dado es par o impar

echo -n "Introduzca un número : "
read n
 
resultado=$(( $n % 2 ))
 
if [ $resultado -eq 0 ]
then
  echo "$n es par"
else
  echo "$n es impar"
fi
