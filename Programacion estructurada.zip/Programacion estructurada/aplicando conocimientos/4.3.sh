#!/bin/bash


echo -n "Deme el primer valor: "
read a
echo -n "Deme el segundo valor: "
read b

#comprobación
if [ "$a" -lt 0  ] ; then
	echo NO
else
	echo OK
fi

