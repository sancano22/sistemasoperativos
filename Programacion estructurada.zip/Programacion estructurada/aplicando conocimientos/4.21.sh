#!/bin/bash
# filestat.sh Crea una estadística de los tipos de ficheros del directorio
# dado y sus subdirectorios
# uso filestat directorioBase

if [ $# -ne 1 ]; then
	echo "Uso: $0 directorioBase";
	exit 1
fi

path=$1

declare -A statarray;

while read line ; do
	tipo=`file -b "$line"`
	let statarray["$tipo"]++;
done< <(find $path -type f -print)

echo ============ Tipo de ficheros y  conteo =============

for tipo in "${!statarray[@]}"; do
	echo $tipo : ${statarray["$tipo"]}
done

