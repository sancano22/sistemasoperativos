#!/bin/bash
#Verificacion de usuario remoto

if ! grep $USER /etc/passwd ; then
	echo "Usuario remoto no controlado localmente"
fi

