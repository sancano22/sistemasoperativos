#!/bin/bash
# redimensiona.sh Redimensiona archivos .jpg y .png del directorio actual

for img in *.png *.jpg
do
	convert $img -resize 800x600 -quality 70 peque_$img
	if [ $? -eq 0 ] ; then
		echo "Redimensionando $img"
	fi
done

