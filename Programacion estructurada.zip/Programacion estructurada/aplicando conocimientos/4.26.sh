#!/bin/bash
# minuscula.sh

# Convierte a minúscula el nombre de todo archivo que se encuentra en el directorio 
# actual.
# Si el nombre ya está en minúscula, no hace ningún cambio


LISTA="$(ls)"

for nombre in $LISTA; do

	if [[ "$nombre" != *[[:upper:]]* ]]; then
		continue
	fi

	ORIGINAL="$nombre"
	NUEVO=`echo $nombre | tr 'A-Z' 'a-z'`

	mv "$ORIGINAL" "$NUEVO"
	echo "* $ORIGINAL renombrado como $NUEVO"
done

