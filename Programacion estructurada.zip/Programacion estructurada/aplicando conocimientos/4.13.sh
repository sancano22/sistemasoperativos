#!/bin/bash
# tojpg Convierte ficheros de imagen a formato jpg
# uso tojpg ficheroImagen

if [ -z "$1" ] ; then
	echo "Uso: tojpg ficheroImagen"
	exit 1
fi

fichero="$1"

ficheroPPM=${fichero%.*}.ppm

case $fichero in
	*.jpg) exit 0 ;;
	*.tga) tgatoppm $fichero > $ficheroPPM ;;
	*.xpm) xpmtoppm $fichero > $ficheroPPM ;;
	*.pcx) pcxtoppm $fichero > $ficheroPPM ;;
	*.tif) tifftoppm $fichero > $ficheroPPM ;;
	*.gif) giftoppm $fichero > $ficheroPPM ;;
	*.pnm|*.ppm) ;;
	*) echo "Formato .${fichero##*.} no soportado"  
	   exit 1 ;;
esac

ficheroSalida=${ficheroPPM%.ppm}.jpg
pnmtojpeg $ficheroPPM > $ficheroSalida

if ! [ $fichero = $ficheroPPM ]; then
	rm $ficheroPPM
fi

