#!/bin/bash
# zmore

#Visualiza archivos de texto comprimidos con gzip

NOARGS=65
NOTFOUND=66
NOTGZIP=67

if [ $# -eq 0 ] # es lo mismo que if [ -z "$1" ]
# $1 existe, pero está vacío:  zmore "" arg2 arg3
then
  echo "Uso: `basename $0` fichero" >&2
  # Salida de error por stderr.
  exit $NOARGS
  # Devuelve el valor 65 como código de error del script.
fi  

fichero=$1

if [ ! -f "$fichero" ]   # Se usan comillas para permitir ficheros con espacios en el nombre.
then
  echo "Fichero $fichero no encontrado!" >&2
  exit $NOTFOUND
fi  

if [ ${fichero##*.} != "gz" ] ; then
  echo "El Fichero $1 no está comprimido con gzip!"
  exit $NOTGZIP
fi  

zcat $1 | more

# Se descomprime con zcat y se muestra con 'more'
# Si se desea se puede usar less

