#!/bin/sh
#Pide un valor numérico (validado) hasta que se introduzca 0


while read -p "Deme un número (0 para salir): " n
do
	if [ $n -eq $n 2> /dev/null ] ; then #numerico
		if [ $n -eq 0 ] ; then
			exit 1
		fi
	fi
done

	
