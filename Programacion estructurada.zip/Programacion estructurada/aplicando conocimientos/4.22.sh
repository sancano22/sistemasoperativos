#!/bin/bash

# numeroRomano.sh
# Rango: 0 - 200
# Uso: numeroRomano numero

LIMITE=200

if [ -z "$1" ] ; then
  echo "Uso: `basename $0` numero"
  exit 1
fi  

numero=$1
if [ "$numero" -gt $LIMITE ] ; then
  echo "Valor fuera del rango [0-200]"
  exit 2
fi  

# Se debe declarar antes de la primera llamada
romano ()   
{
	number=$1
	factor=$2
	rchar=$3
	let "resto = number - factor"
	while [ "$resto" -ge 0 ] ; do
  		echo -n $rchar
  		let "number -= factor"
  		let "resto = number - factor"
	done  

return $number
       # Funciona mediante división por extracción sucesiva.
}

romano $numero 100 C
numero=$?
romano $numero 90 XC
numero=$?
romano $numero 50 L
numero=$?
romano $numero 40 XL
numero=$?
romano $numero 10 X
numero=$?
romano $numero 9 IX
numero=$?
romano $numero 5 V
numero=$?
romano $numero 4 IV
numero=$?
romano $numero 1 I

echo

