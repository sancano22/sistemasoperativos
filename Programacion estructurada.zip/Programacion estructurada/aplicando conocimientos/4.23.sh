#!/bin/bash
# mcdEuclides.sh: Máximo Común Divisor mediante el Algoritmo de Euclides

#  El Algoritmo de Euclides usa divisiones sucesivas
#  En cada paso:
#+ dividendo <---  divisor
#+ divisor  <---  resto
#+ Hasta que resto = 0.
#+ MCD = dividendo, en el último paso.



# ------------------------------------------------------
# Comprobación de los argumentos

if [ $# -ne "2" ] ; then
  echo "Uso: `basename $0` primerNumero segundoNumero"
  exit 1
fi

# ------------------------------------------------------

mcd ()
{

  dividendo=$1                   # Asignación arbitraria.
  divisor=$2                     # No importa cuál es el mayor.

  resto=1                    

  until [ "$resto" -eq 0 ]
  do
    let "resto = $dividendo % $divisor"
    dividendo=$divisor           # Se repite con dos números menores.
    divisor=$resto
  done                           

}                                


mcd $1 $2

echo; echo "MCD de $1 y $2 = $dividendo"; echo

