#!/bin/bash
# korncd Función que implementa la función cd del Korn Shell


function cd
{
	case $# in
		0|1) 	builtin cd $@ ;;
		2) 	destino=${PWD//$1/$2}
			if [ $destino = $PWD ] ; then
				echo "Sustitución a $destino no válida"
			elif ! cd $destino ; then
				echo "Directorio $destino no válido"
			fi ;;
		*)	echo "Número erróneo de argumentos" ;;
	esac
}

