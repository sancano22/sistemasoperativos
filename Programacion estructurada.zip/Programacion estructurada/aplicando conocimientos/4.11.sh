#!/bin/bash
# Lista los directorio de /home

for fichero in /home/*
do
	if [ -d $fichero ] ; then
		echo "$fichero"
	fi
done

