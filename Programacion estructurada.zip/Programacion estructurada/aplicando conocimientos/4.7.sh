#!/bin/bash
# fileinfo.sh Información sobre un fichero
# uso fileinfo fichero

if [ -z "$1" ] ; then
	echo "Uso: fileinfo fichero"
	exit 1
fi

Fichero="$1"

if [ -f $Fichero ] ; then
	echo "Información del fichero $Fichero"
	echo "Tamaño: `ls -lh $Fichero | awk '{ print $5 }'` bytes"
	echo "Tipo: `file $Fichero | cut -d":" -f2 -`"
	echo "Inodo nº: `ls -i $Fichero | cut -d" " -f1 -`"
	echo "Punto de montaje: `df -h $Fichero | grep -v Montado | \
		awk '{ print $1 " dentro de la partición " $6}'`"
else
	echo "El fichero $Fichero no existe"
fi
