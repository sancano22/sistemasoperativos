#!/bin/bash
#Imprime los pares entre 1 y 100
for ((  i = 2 ;  i <= 100;  i+=2  ))
do
  echo " $i "
done

