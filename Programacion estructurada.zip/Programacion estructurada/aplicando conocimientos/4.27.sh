#! /bin/bash
# hanoi.sh Las torres de hanoi
# Uso: hanoi Nº de fichas

Hanoi() {
    case $1 in
    0)
        ;;
    *)
        Hanoi "$(($1-1))" $2 $4 $3
        echo Mover $2 "-->" $3
        Hanoi "$(($1-1))" $4 $3 $2
        ;;
    esac
}

case $# in
1)
    case $(($1>0)) in
    1)
        Hanoi $1 1 3 2
        exit 0;
        ;;
    *)
        echo "$0: Número incorrecto de fichas.";
	echo "Recuerde; Nº de fichas > 0"
        exit 2;
        ;;
    esac
    ;;
*)
    echo "Uso: $0 Número de fichas"
    exit 1;
    ;;
esac

