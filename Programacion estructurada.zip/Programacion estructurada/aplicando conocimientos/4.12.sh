#!/bin/bash
# Identifica los enlaces a un fichero
# Uso: lnks fichero [directorio]
if [ $# -eq 0 -o $# -gt 2 ]; then
	echo "Uso: lnks fichero [directorio]" 1>&2
	exit 1
fi
if [ -d "$1" ]; then
	echo "El primer argumento no puede ser un directorio." 1>&2
	echo "Uso: lnks fichero [directorio]" 1>&2
	exit 1
else
	fichero="$1"
fi

if [ $# -eq 1 ]; then
	directorio="."
elif [ -d "$2" ]; then
	directorio="$2"
else
	echo "El parámetro opcional debe ser un directorio." 1>&2
	echo "Uso: lnks fichero [directorio]" 1>&2
	exit 1
fi

# Comprueba que el archivo existe y es un fichero regular
if [ ! -f "$fichero" ]; then
	echo "lnks: $fichero no encontrado o no es un fichero regular" 1>&2
	exit 1
fi

# Comprueba los enlaces al archivo
set -- $(ls -l "$fichero")
linkcnt=$2
if [ "$linkcnt" -eq 1 ]; then
	echo "lnks: no hay enlaces al fichero $fichero" 1>&2
	exit 0
fi

# Obtiene el inodo del archivo dado
set $(ls -i "$fichero")
inodo=$1

# Encuentra e imprime los archivos con ese número de inodo
echo "lnks: usando find para encontrar los enlaces..." 1>&2
find "$directorio" -xdev -inum $inodo -print

