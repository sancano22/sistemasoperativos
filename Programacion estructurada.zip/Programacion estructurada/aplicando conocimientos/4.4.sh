#!/bin/sh
#Comprueba si la entrada es un valor numérico
if [ -z $1 ] ; then
	echo "Uso: $0 número"
	exit 1
fi

if [ $1 -eq $1 2> /dev/null ] ; then
	echo $1 es numérico ;
else 
	echo $1 no es numérico ;
fi 
