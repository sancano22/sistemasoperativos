#!/bin/bash
# menuSelect.sh Muestra un menú mediante select
# Dicho comando se implementa dentro una función

PS3="Seleccione su lenguaje de programación favorito: "

Menu()
{
	select lenguaje 
	do
		if [ "$lenguaje" == "" ] ; then
			echo -e "Opción incorrecta\n"
			continue
		elif [ $lenguaje = SALIR ] ; then
			echo "Hasta la próxima"
			break
		fi

		echo "Su lenguaje favorito es $lenguaje"
		echo -e "Es la opción número $REPLY\n"
	done
}

Menu Bash Awk Java C++ SALIR

