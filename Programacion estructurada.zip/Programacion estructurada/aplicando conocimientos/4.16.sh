#!/bin/bash
# dns.sh Muestra la información del DNS de los sitios google.com y yahoo.com

for HOST in www.google.com www.yahoo.com
do
  echo "-----------------------"
  echo $HOST
  echo "-----------------------"
  
  /usr/bin/host $HOST
  echo "-----------------------"

done

