#!/bin/bash
# Verifica la ejecución como root

function chkroot()
{
if [ $(whoami) != "root" ] ;  then
 		echo "Debe ser root para ejecutar el script"
 		exit 1
fi
}

chkroot
echo "Hola root"

