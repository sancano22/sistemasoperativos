#!/bin/bash
# chkroot Comprueba que el script se ejecute en modo root

if [ $UID -ne 0 ]
then
    echo "Debe ejecutar el script como root"
    exit 1
fi
echo "Programa en ejecución en modo root"

