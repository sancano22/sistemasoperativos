#!/bin/bash 
# 4-19.sh Ejemplo de uso de break y continue


for ((i=0; i<10; i++))
do
	if [ $i -le 3 ] ; then
		echo "Continue"
		continue
	fi

	echo $i

	if [ $i -ge 8 ] ; then 
		echo "Break"
		break
	fi
done

