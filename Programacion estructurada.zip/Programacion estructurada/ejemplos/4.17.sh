#!/bin/bash
#
# Obtiene el nombre de usuario de /etc/passwd.

fichero=/etc/passwd
usuario=$1

if [ $# -ne "1" ]
then
  echo "Uso: `basename $0` nombreUsuario"
  exit 1
fi  

while read linea ; do
  	echo "$linea" | grep $1 | awk -F":" '{ print $5 }'  
done <$fichero  # Redirección a la función.

