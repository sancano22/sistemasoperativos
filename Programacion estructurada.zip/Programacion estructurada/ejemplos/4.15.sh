#!/bin/bash
# lotes.sh Genera ficheros vacíos

for nombre in {1..100}.txt
do
	touch $nombre
done

