#!/bin/bash
# Lista los directorios de PATH

path=$PATH

while [ $path ] ; do
	echo ${path%%:*}
	if [ ${path#*:} = $path ] ; then
		path=
	else
		path=${path#*:}
	fi
done

