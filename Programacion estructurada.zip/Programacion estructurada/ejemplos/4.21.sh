#!/bin/bash
# 4-21.sh Muestra un menú mediante select

PS3="Seleccione su lenguaje de programación favorito: "

select lenguaje in Bash Java C++ PHP SALIR
do
	if [ "$lenguaje" == "" ] ; then
		echo -e "Opción incorrecta\n"
		continue
	elif [ $lenguaje = SALIR ] ; then
		echo "Hasta la próxima"
		break
	fi

	echo "Su lenguaje favorito es $lenguaje"
	echo -e "Es la opción número $REPLY\n"
done

