#!/bin/bash
# chkargs Comprueba el número de argumentos

if test $# -eq 0
then
    echo "Debe indicar al menos un argumento"
    exit 1
fi
echo "Programa en ejecución"

