#!/bin/bash
# listarCSV Lista un fichero de formato CSV

datos="nombre,apellidos,sexo,direccion"
oldIFS=$IFS
IFS=','
for item in $datos
do
	echo "Item: $item"
done
IFS=$oldIFS

