#!/bin/bash
for ((  i = 0 ;  i < 6;  i++  ))
do
  echo $(($RANDOM%20))
done

