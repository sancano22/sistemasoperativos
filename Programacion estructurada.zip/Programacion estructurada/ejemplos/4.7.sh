#!/bin/bash
# redireccion.sh Redirección en un condicional
# uso redireccion [fichero]

if [ -z "$1" ] ; then
  Fichero=nombres.data   # Fichero por defecto.
else
  Fichero=$1
fi  

TRUE=1

if [ "$TRUE" ] ; then
 read name
 echo $name
fi <"$Fichero"
#  ^^^^^^^^^^^^ Redirección al condicional

