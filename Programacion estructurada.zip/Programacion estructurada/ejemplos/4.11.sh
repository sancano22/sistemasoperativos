#!/bin/bash
# listarDir Lista en detalle los ficheros del directorio actual

for fichero in *
do
	ls -l "$fichero"
done

