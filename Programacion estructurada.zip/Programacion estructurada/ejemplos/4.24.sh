#!/bin/bash
# ubicame.sh Script que muestra el ámbito de las variables
# Uso ubicame 

function Ubicame
{
	donde='Dentro de la función'
}

donde='En el script'
echo $donde
Ubicame
echo $donde

