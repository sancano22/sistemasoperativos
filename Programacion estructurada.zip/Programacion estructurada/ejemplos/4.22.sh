#!/bin/bash
# saluda.sh Script que llama a una función para saludar
# Uso saluda nombre

function Saluda
{
	echo "Hola $1"
}

Saluda

