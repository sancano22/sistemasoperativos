#!/bin/bash 
# suma.sh Ejemplo de uso de return
# uso Suma
function suma (){
        c=$(expr $a + $b)
        return $c
}

a=5
b=10
suma $a $b
resultado=$?

echo $resultado

