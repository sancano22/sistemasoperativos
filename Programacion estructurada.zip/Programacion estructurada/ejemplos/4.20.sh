#!/bin/bash
# 4-19.sh Muestra un menú mediante select

echo "Seleccione su lenguaje de programación favorito: "

select lenguaje in Bash Java C++ PHP
do
	echo "Buena elección!"
done

