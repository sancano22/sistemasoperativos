#!/bin/bash
# verFicheros.sh Muestra el contenido de los ficheros pasados como argumentos
# Uso: verFicheros [-v] fichero1 ...

if [ $# -eq 0 ] ; then
    echo "Uso: verFicheros [-v] fichero1 ..." 1>&2
    exit 1
fi

if [ "$1" = "-v" ] ; then
    shift
    less -- "$@"
else
    cat -- "$@"
fi

