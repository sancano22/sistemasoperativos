#!/bin/bash
# ubicame.sh Script que muestra el ámbito de las variables
# Uso ubicame 

function Ubicame
{
	local donde='Dentro de la función'
	usuario=Gonzalo
}

donde='En el script'
echo $donde
Ubicame
echo $donde
echo "Soy $usuario"

