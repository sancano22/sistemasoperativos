#!/bin/bash
# Itera hasta que se introduzca la palabra secreta

secreta=gonzalo
palabra=desconocida

echo "Adivine la palabra secreta"
echo
until [ "$palabra" = "$secreta" ] ; do
	echo -n "Palabra: "
	read palabra
done

echo "Bien Hecho!"

