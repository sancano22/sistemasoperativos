#!/bin/bash
# argumentos Lista los argumentos que recibe

for arg in "$*"
do
	echo "Elemento: $arg"
done

for arg in "$@"
do
	echo "Elemento: $arg"
done

