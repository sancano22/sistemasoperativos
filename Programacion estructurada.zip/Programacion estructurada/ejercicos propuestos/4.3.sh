function chkroot()
{
	ROOTUSER_NAME=root
username=`id -nu`
if ["$username" != "$ROOTUSER_NAME" ] ;  then
 		echo "Debe ser root para ejecutar el script"
 		exit 1
fi
}

