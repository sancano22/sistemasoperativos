#! /bin/bash
# unzipDir Descomprime todos los archivos zip de un directorio dado

if [ -z $1 ] ; then
	echo "Uso: unzipDir Directorio"
	exit 1
fi


# Se buscan los ficheros con extensión .zip
for fichero in `find $1 -name "*.zip*" -type f`
do
	# Se elimina la extensión .zip
	directorio=`echo ${fichero} | awk -F '.' '{print $1}'`
	echo "Directorio: $directorio"

	# Se crea el directorio
	mkdir $directorio

	# Copiado del archivo zip al nuevo directorio y acceso al mismo
	cp ${fichero} ${directorio}
	cd $direccion

	# Descompresión del archivo en el nuevo directorio
	unzip ${directorio}/$(echo ${fichero##/*/})
done


