#!/bin/bash
#Pide cinco valores numéricos numéricos (validados) hasta que se introduzca 0
#Tras esto calcula la suma y media de los valores introducidos

num=0 #número de valores introducidos
suma=0 #suma de los valores introducidos
#vector para almacenar los numeros
declare -a numeros


while [ $num -lt 5  ]; do
	read -p "Deme un número: " n
	if [ $n -eq $n 2> /dev/null ] ; then #numérico
		numeros[$num]=$n
		suma=`expr $suma + $n`
		num=`expr $num + 1`
	fi
done

#se calcula la media
media=$(($suma/$num))
echo
echo Media=$media
echo
echo Valores introducidos mayores a la media:
#se recorre el vector
for i in "${numeros[@]}" ; do
	if [ $i -gt $media ] ; then
		echo $i
	fi
done
