#!/bin/bash
# SCRIPT : quicksort.sh Ordena una lista de números mediante el Algoritmo Quicksort
# USO : quicksort.sh


imprimirNumeros()
{
   echo ${ARRAY[*]}
}

quicksort()
{

    local array=( `echo "$@"` )
    local -a l
    local -a g
    local -a e
    local x=

    if [ ${#array[@]} -lt 2 ]; then
        echo -n ${array[@]}
    else
        local pivote=${array[0]}

        for x in ${array[@]}
        do

          if [ $x -lt $pivote ]
          then
              l=( ${l[@]} $x )
          elif [ $x -gt $pivote ]
          then
              g=( ${g[@]} $x )
          else
              e=(${e[@]} $x)
          fi

        done

      echo "`quicksort "${l[@]}"` ${e[@]} `quicksort "${g[@]}"`"

    fi
}

#####################################################################
#                       DECLARACIÓN DE VARIABLES                    #
#####################################################################

clear

echo "Introduzca los números a ordenar : "

read -a ARRAY

count=${#ARRAY[@]}

#####################################################################
#                       Llamadas a funciones                        #
#####################################################################

echo "--------------------------------------------------------------"

echo "Números antes de la ordenación:"

imprimirNumeros


echo "Números tras la ordenación: "

quicksort "${ARRAY[@]}"

echo "--------------------------------------------------------------"

