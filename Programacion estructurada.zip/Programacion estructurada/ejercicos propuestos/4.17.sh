#! /bin/bash
# testIP.sh Monitoriza la disponibilidad de una máquina.
# El bucle acaba cuando la máquina responda a ping

read -p "Introduzca la dirección IP: " ipadd

until ping -c 1 $ipadd
do
        sleep 60
done

