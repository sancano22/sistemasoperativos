#!/bin/bash
# listaPath Lista los ficheros ejecutables que se encuentren en los directorios
# de la variable de entorno PATH

#Función que lista los ejecutables de un directorio
function listarEjecutables
{
	IFS=' 
'
	ficheros=$(ls -1 $1)
	for fichero in $ficheros
	do
		pathFichero="$1/$fichero"
		if [ -x $pathFichero ] ; then
			echo $pathFichero
		fi
	done
	IFS=':'
}

IFS=':'
 

for dir in $PATH
do
	if [ -z "$dir" ] ; then
		echo "Directorio vacío encontrado"
		exit 1
	elif ! [ -d "$dir" ] ; then
		echo "$dir no es un directorio válido"
		exit 1
	else
		listarEjecutables $dir
	fi
done

