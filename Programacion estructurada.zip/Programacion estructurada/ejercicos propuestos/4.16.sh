#! /bin/bash
# monitorLog.sh Monitoriza el tamaño del fichero de log y realiza una copia
# del mismo cuando su tamaño supera los 2000 bytes 

fichero=/tmp/logfile

until [ $(ls -l $fichero | awk '{print $5}') -gt 2000 ]
        do            
            sleep 5
        done
date=`date +%s`
cp $fichero "$fichero-"$date.bak

