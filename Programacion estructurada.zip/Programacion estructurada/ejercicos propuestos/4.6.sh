#!/bin/bash
# Comprueba si el año en curso es bisiesto

anio=`date +%Y`

if (( ($anio % 400) == "0" )) || (( ($anio % 4 == "0" ) && ($anio % 100 != "0" ) )) ; then
	echo Este año es bisiesto
else
	echo Este año no es bisiesto
fi
