#!/bin/bash
# Comprueba si el año en curso es bisiesto

anio=`date +%Y`

cond1=$(($anio%400))
cond2=$(($anio%4))
cond3=$(($anio%100))


if [ $cond1 -eq "0" ] ; then
	echo Este año es bisiesto
elif [ $cond2 -eq "0" -a $cond3 -ne "0" ] ; then
	echo Este año es bisiesto
else
	echo Este año no es bisiesto
fi



