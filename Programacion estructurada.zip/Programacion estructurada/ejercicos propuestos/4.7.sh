#!/bin/bash
# menu Implementa un menu usando case

echo -e "\n	MENÚ DE COMANDOS\n"
echo " 1. Mostrar la fecha del sistema"
echo " 2. Mostrar los usuarios conectados"
echo " 3. Mostrar el nombre del directorio de trabajo"
echo " 4. Listar el contenido del directorio de trabajo"

read -p "> " opcion

echo

case "$opcion" in
	1)	date ;;
	2)	who  ;;
	3)	pwd  ;;
	4)	ls   ;;
	*) 	echo "Opción incorrecta" ;;
esac

