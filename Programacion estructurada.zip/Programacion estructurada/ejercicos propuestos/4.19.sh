#!/bin/bash
# menu.sh Muestra varios mensajes por pantalla.
# captura CTRL+C, CTRL+Z y quit usando el comando trap
trap '' SIGINT
trap ''  SIGQUIT
trap '' SIGTSTP
 
# Muestra un mensaje y pausa la ejecución
pause(){
	local m="$@"
	echo "$m"
	read -p "Presione [Enter] para continuar..." key
}
 
# bucle infinito
while :
do
	# Muestra el menú
	clear
	echo "---------------------------------"
	echo "	     MENU DE OPCIONES"
	echo "---------------------------------"
	echo "1. Mostrar la fecha del sistema"
	echo "2. Mostrar usuarios y uso"
	echo "3. Top 10 de consumo de memoria"
	echo "4. Top 10 de consumo de CPU"
	echo "5. Mostrar estadísticas de red"
	echo "6. Salir"
	echo "---------------------------------"
	read -r -p "Introduzca su opción [1-6] : " c
	# take action
	case $c in
		1) pause "$(date)";;
		2) w| less;;
		3) echo '*** Top 10 de consumo de memoria:'; ps -auxf | sort -nr -k 4 | head -10;
		   echo;  pause;;
		4) echo; echo '*** Top 10 de consumo de CPU:';ps -auxf | sort -nr -k 3 | head -10;
		   echo;  pause;;
		5) netstat -s | less;;
		6) break;;
		*) Pause "Opción incorrecta. Recuerde [1-6]"
	esac
done

