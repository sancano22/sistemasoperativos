#! /bin/bash
# media Calcula la media aritmética de la serie de números introducidos

NUMERO="0"
MEDIA="0"
SUMA="0"
CONTADOR="0"

while true ; do
	echo -n "Introduzca un número en el rango [0 - 100] ('q' para quitar): "
	read NUMERO

	if (("$NUMERO" < "0")) || (("$NUMERO" > "100")) ; then
		echo "Debe introducir un valor en el rango [0-100]"
	elif [ "$NUMERO" == "q" ] ; then
		break
	else
		SUMA=$[$SUMA + $NUMERO]
		CONTADOR=$[$CONTADOR + 1]
		MEDIA=$[$SUMA / $CONTADOR]
	fi
done

echo "La media es $MEDIA"

