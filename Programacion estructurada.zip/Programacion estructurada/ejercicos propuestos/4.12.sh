#!/bin/bash
# adivinaNumero.sh Juego para adivinar un número comprendido entre 0 y 99

let intentos=10
let solucion=$RANDOM%100

while ((intentos-->0))
do
	read -p "Indique un número: " numero
	if ((numero==solucion)) ; then
		echo "Enhorabuena!, el número era $solucion"
		exit
	elif ((numero<solucion)) ; then
		echo "El número buscado es mayor"
	else
		echo "El número buscado es menor"
	fi
done

echo "Lo siento. Ha superado los 10 intentos"

