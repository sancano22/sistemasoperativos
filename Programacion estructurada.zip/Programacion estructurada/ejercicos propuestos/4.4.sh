grep $USER /etc/passwd 
if [ $? –ne 0] ; then	#captura de la salida de los comandos anteriores
echo "Usuario remoto no controlado localmente"
fi

