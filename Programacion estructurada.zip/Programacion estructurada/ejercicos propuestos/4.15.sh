#! /bin/bash
# leerFichero.sh Muestra por la salida estándar el contenido del fichero que 
# se le indica

echo -e "Indique la ruta absoluta del fichero a mostrar:"

read fichero
exec <$fichero # redirección de la entrada estándar a fichero

while read linea ; do
	echo $linea
done

