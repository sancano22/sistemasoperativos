#!/bin/bash
# makepath.sh Crea la estructura de directorios indicada

function makepath()
{
	if [[ ${#1} -eq 0 || -d "$1" ]] ; then
		return 0 # salir
	fi

	if [[ "${1%/*}" = "$1" ]] ; then
		mkdir $1
		return $?
	fi

	makepath ${1%/*} || return 1
	mkdir $1
	return $?
}

