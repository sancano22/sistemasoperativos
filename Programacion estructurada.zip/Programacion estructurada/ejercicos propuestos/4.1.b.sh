#!/bin/bash
# Pide tres números y los devuelve ordenados

echo -n " Introduce el primer valor: "
read n1
echo -n " Introduce el segundo valor: "
read n2
echo -n " Introduce el tercer valor: "
read n3



echo Valores ordenados:
# Ahora hacemos un 'echo' con cada uno de los números en una
# línea diferente y aplicamos el comando 'sort' con un pipe así:
echo -e "${n1}\n${n2}\n${n3}" | sort -n
# la opción '-n' es para que ordene números, aunque sin ella también lo hace.

