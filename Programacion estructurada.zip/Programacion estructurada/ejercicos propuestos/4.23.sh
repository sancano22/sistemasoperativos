#! /bin/bash
# busquedaBinaria.sh
# Algoritmo de Búsqueda binaria

BusquedaBinaria()
{
    estado=-1
    i=1
    array=($(echo "$@"))
    indiceInferior=0
    indiceSuperior=$((${#array[@]}-1))

    while [ $indiceInferior -le $indiceSuperior ] ; do

        indiceMedio=$(($indiceInferior+($indiceSuperior-$indiceInferior)/2))
	     elementoMedio=${array[$indiceMedio]}

        if [ $elementoMedio -eq $elementoBuscado ] ; then
            estado=0
            busquedas=$i
            return
        elif [ $elementoBuscado -lt $elementoMedio ] ; then
            indiceSuperior=$(($indiceMedio-1))
        else
            indiceInferior=$(($indiceMedio+1))
        fi

        let i++

    done
}

#Se crea un vector de elementos
elementos=( `seq 0 100` )

#totalElementos=${#a[@]}
elementoBuscado=51

BusquedaBinaria "${elementos[@]}"

if [ $estado -eq 0 ] ; then
         echo "Elemento $elementoBuscado encontrado tras $busquedas iteraciones"
else
         echo "$elementoBuscado no encontrado en el vector"
fi

