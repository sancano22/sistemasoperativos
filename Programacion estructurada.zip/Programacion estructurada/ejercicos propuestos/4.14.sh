#! /bin/bash
# escribirFichero.sh Lee datos desde la entrada estándar y los almacena en un fichero
# cuya dirección absoluta se le indica

echo -e "Indique la ruta absoluta del fichero a crear:"
read fichero

echo -e "Introduzca el contenido (Ctrl+C para terminar):"

while read linea ; do
	echo $linea >> $fichero
done

