#! /bin/bash
# locktty Bloquea el terminal hasta que se introduzca la clave secreta

trap '' 1 2 3 18
stty -echo
echo -n "Introduzca la palabra secreta: "
read key_1
echo
echo -n "Repita la palabra secreta: "
read key_2
echo
key_3=
if [ "$key_1" = "$key_2" ] ; then
	tput clear
	until [ "$key_3" = "$key_2" ]
	do
		read key_3
	done
else
	echo "locktty: Las palabras dadas no coinciden" 1>&2
fi
stty echo

