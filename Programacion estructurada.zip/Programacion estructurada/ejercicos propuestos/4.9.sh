#!/bin/bash
# ocupa.sh Informa del tamaño del directorio que se le indica

if [ -z $1 ] ; then
	echo "Uso: ocupa Directorio"
	exit 1
fi

#obtiene los directorios y su tamaño en una lista
lista=$(du -k $1)
IFS='
'

for fila in $lista
do
	dir=$(echo $fila|cut -f 2)
	let kb=$(echo $fila|cut -f 1)
	let b=1024*kb
	let mb=kb/1024
	echo "$dir: $mb MB, $kb KB, $b B"  
done

