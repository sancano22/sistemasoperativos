#!/bin/bash
# Pide tres números y los devuelve ordenados

echo -n " Introduce el primer valor: "
read n1
echo -n " Introduce el segundo valor: "
read n2
echo -n " Introduce el tercer valor: "
read n3

if [ $n1 -lt $n2 ]; then 
     if [ $n2 -lt $n3 ]; then
        if [ $n1 -lt $n3 ]; then
           echo "$n1 $n2 $n3" 
        else 
           echo "$n1 $n3 $n2" 
        fi 
     else
        if [ $n1 -lt $n3 ]; then
                echo "$n1 $n3 $n2"
          else
                echo "$n3 $n1 $n2" 
        fi
        
     fi
else 
     if [ $n2 -lt $n3 ]; then
        if [ $n1 -lt $n3 ]; then
           echo "$n2 $n1 $n3" 
        else 
           echo "$n2 $n3 $n1" 
        fi 
     else
        if [ $n1 -lt $n3 ]; then
                echo "$n1 $n2 $n3"
          else
                echo "$n3 $n2 $n1" 
        fi
        
     fi
fi
