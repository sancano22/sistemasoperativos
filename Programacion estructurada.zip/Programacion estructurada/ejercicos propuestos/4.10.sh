#!/bin/bash
#Name: frecuenciaPalabra.sh
#Descripción: Calcula la frecuencia de cada palabra en un fichero de texto

if [ $# -ne 1 ] ; then
	echo "Uso: $0 fichero";
	exit -1
fi

fichero=$1
egrep -o "\b[[:alpha:]]+\b" $fichero | \
awk '{ count[$0]++ }
END{ printf("%-14s%s\n","Palabra","Apariciones") ;
for(ind in count)
{ printf("%-14s%d\n",ind,count[ind]); }
}'

